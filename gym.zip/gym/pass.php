<?php
$pass="98f13708210194c475687be6106a3b84";
$pass1=md5($pass);
echo"$pass1";
?>