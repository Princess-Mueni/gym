<div class="container" >
				<ul class="main-menu" style="margin-top:0%;background-color:green;">
					<li><a href="index.php" class="active">Home</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contact.php">Contact</a></li>
					
					<?php if(strlen($_SESSION['uid'])==0): ?>
			<li><a href="admin/">Admin</a></li>
					<?php else :?>
						<li><a href="login.php">login</a></li>
						<?php endif;?>
				</ul>
			</div>